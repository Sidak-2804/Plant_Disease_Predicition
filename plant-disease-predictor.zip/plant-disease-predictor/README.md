
# 🌱 Plant Disease Predictor

A simple frontend project that lets you upload an image and simulates plant disease prediction.

## 💻 Setup

Open `index.html` in any modern web browser.

## 🧠 Features

- Upload leaf image
- Preview before prediction
- Simulated disease prediction

## 📁 Structure

- `index.html` – main interface
- `assets/` – images and styles
- `scripts/` – JavaScript logic
