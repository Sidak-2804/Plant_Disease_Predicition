
let imagePath = "";

function previewImage(event) {
  const image = event.target.files[0];
  if (!image) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    document.getElementById('imagePreview').innerHTML = `<img src="${e.target.result}" alt="Uploaded Image" />`;
    imagePath = e.target.result;
  };
  reader.readAsDataURL(image);
}

function predictDisease() {
  if (!imagePath) {
    document.getElementById("result").innerText = "Please upload an image first.";
    return;
  }

  document.getElementById("result").innerText = "Predicting...";
  setTimeout(() => {
    document.getElementById("result").innerText = "Predicted Disease: Powdery Mildew";
  }, 1500);
}
